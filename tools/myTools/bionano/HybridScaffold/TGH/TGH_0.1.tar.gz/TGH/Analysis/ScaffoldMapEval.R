#This script evaluate the quality of a hybrid-scaffold base on a reference in BNG map space
sandwich.hybrid.dir <- ""
