tgh.dir <- "~/RemoteServer//mnt/bionf_tmp/apang/orangutan/hybrid_scaffolds/output/TGH_M1/"
out.dir <- "~/RemoteServer/home/users/jwang/workspace/HybridScaffold/HybridScaffodTwo/TestUWExport/Susie_Orangutan/"
file.list <- dir(paste0(tgh.dir, "/Sandwich2/"), pattern = "test_2col", full.names = T)
file.list <- c(file.list[3], file.list[1], file.list[2])
merged.cmap <- get.merged.cmap(file.list)
exportCMap(merged.cmap, out.dir, "Merged_HYBRIDS_Export_r.cmap")
