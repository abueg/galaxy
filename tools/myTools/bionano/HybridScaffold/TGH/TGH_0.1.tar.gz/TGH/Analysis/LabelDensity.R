getLabelDensity2 <- function(ref.list, genome.size.list, names.list, win.size = 500e3, overlap.size = 300e3){
  getLabelDensity.per.chr <- function(Position){
    if(tail(Position,1) - head(Position,1) < win.size){
      return(-1)
    }
    win.starts <- seq(head(Position,1), tail(Position,1)-win.size, (win.size-overlap.size))
    win.ends <- win.starts + win.size
    label.ind.start <- findInterval(win.starts, Position)
    label.ind.end <- findInterval(win.ends, Position)
    label.density <- (label.ind.end - label.ind.start)/(win.size)*100e3
    #browser()
  }
  label.density.list <- lapply(ref.list, function(ref){
    ld <- ref[,getLabelDensity.per.chr(sort(Position)), by=CMapId]
    ld$V1
  })

  #label.density.merged <- list2df(label.density.list, names.list)
  #g <- ggplot(label.density.merged)
  #g <- geom_density(aes(x=))
  stats <- getNormalizedHist(label.density.list, genome.size.list, names.list, breaks=seq(1,55,2), xlim=c(1,50))
  #browser()
  g <- ggplot(stats)
  g <- g + geom_line(aes(x=Value, y=Density, colour=Name))
  g <- g + xlab("Label Density (Sites/100Kb)") + ylab("Normalzied Count")
  plot(g)
  g2 <- ggplot(stats)  + geom_line(aes(x=Value, y=CumProb, colour=Name))
  g2 <- g2 + xlab("Label Density (Sites/100Kb)") + ylab("Cumulative Prob")
  g2 <- g2 + scale_x_continuous(breaks=seq(1,50,2))
  plot(g2)
}


getNormalizedHist <- function(dat.list, scale.list=c(1,1), names.list=c("Group1", "Group2"), breaks="Sturges", plot=F, xlim=c(-Inf, Inf), reverse.cum=F){
  stat.list <- mapply(function(df, size){
    df <- df[df >= xlim[1] & df <= xlim[2]]
    h <- hist(df, breaks = breaks, plot=F);
    if(reverse.cum){
      stat <- data.table(Value=h$mids, Count=h$counts/size, CumSum=rev(cumsum(rev(h$counts/size))),
                         Density=h$density*diff(h$breaks), CumProb=rev(cumsum(rev(h$density*diff(h$breaks)))))
    }else{
      stat <- data.table(Value=h$mids, Count=h$counts/size, CumSum=cumsum(h$counts/size),
                         Density=h$density*diff(h$breaks), CumProb=cumsum(h$density*diff(h$breaks)))
    }
  }, dat.list, scale.list, SIMPLIFY = F)
  stats.merged <- list2df(stat.list, names.list)
  if(plot){
    g <- ggplot(stats.merged) + geom_line(aes(x=Value, y=Count, colour=Name)) + ylab('Normalized Counts')
    plot(g)
    g2 <- ggplot(stats.merged) + geom_line(aes(x=Value, y=CumSum, colour=Name)) + ylab('Normalized Cumulative Counts')
    plot(g2)
  }
  return(stats.merged)
}
