#this script compute statistics for two-enzyme hybrids
