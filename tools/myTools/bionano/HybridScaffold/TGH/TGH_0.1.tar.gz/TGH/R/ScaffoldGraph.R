#This script process hybrid scaffold as graph and 

